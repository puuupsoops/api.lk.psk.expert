<?php

namespace API\v1\Models\Registers;

/**
 * Список услуг в 1С
 */
class Services1C
{
    /** @var string Отгрузка: Другая транспортная, Транспортные расходы 900 */
    public const shipment900 = "deb4f821-b4ca-11df-9585-0050569a3a91";
}